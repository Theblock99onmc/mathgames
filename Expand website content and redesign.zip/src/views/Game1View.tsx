import { useState, useEffect, useRef } from 'react';
import type { Level } from '../types';
import { saveG1Stat } from '../utils/stats';

interface Question { text: string; answer: number; label: string; }

function generateQuestions(count: number, level: number): Question[] {
  const list: Question[] = [];
  for (let i = 0; i < count; i++) {
    const maxNum = level === 1 ? 20 : level === 2 ? 50 : 100;
    const a = Math.floor(Math.random() * maxNum) + 1;
    const b = Math.floor(Math.random() * (level === 1 ? 12 : 25)) + 1;
    const opType = Math.floor(Math.random() * (level === 1 ? 2 : 4));
    if (opType === 0) { list.push({ text: `${a} + ${b} = ?`, answer: a + b, label: 'Optellen' }); }
    else if (opType === 1) { const mx = Math.max(a,b), mn = Math.min(a,b); list.push({ text: `${mx} − ${mn} = ?`, answer: mx - mn, label: 'Aftrekken' }); }
    else if (opType === 2) { const m1 = Math.floor(Math.random()*12)+2, m2 = Math.floor(Math.random()*12)+2; list.push({ text: `${m1} × ${m2} = ?`, answer: m1*m2, label: 'Vermenigvuldigen' }); }
    else { const base = Math.floor(Math.random()*8)+2; list.push({ text: `${base}² = ?`, answer: base*base, label: 'Kwadraten' }); }
  }
  return list;
}

function drawBellCurve(canvas: HTMLCanvasElement, userAvg: number) {
  const ctx = canvas.getContext('2d'); if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr; canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);
  const w = rect.width, h = rect.height, pad = 24;
  ctx.clearRect(0, 0, w, h);
  const mean = 4.0, sd = 1.2, minX = 0.5, maxX = 7.5;
  const gauss = (x: number) => (1/(sd*Math.sqrt(2*Math.PI)))*Math.exp(-0.5*((x-mean)/sd)**2);
  const cW = w - pad*2, cH = h - pad*2, maxG = gauss(mean);

  ctx.beginPath(); ctx.moveTo(pad, h-pad);
  for (let px = 0; px <= cW; px++) {
    const xv = minX + (px/cW)*(maxX-minX);
    ctx.lineTo(pad+px, (h-pad) - (gauss(xv)/maxG)*cH);
  }
  ctx.lineTo(w-pad, h-pad); ctx.closePath();
  const g = ctx.createLinearGradient(0,0,0,h);
  g.addColorStop(0, 'rgba(99,102,241,0.35)'); g.addColorStop(1, 'rgba(99,102,241,0.04)');
  ctx.fillStyle = g; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = '#6366f1'; ctx.stroke();

  const cl = Math.max(minX, Math.min(maxX, userAvg));
  const ux = pad + ((cl-minX)/(maxX-minX))*cW;
  const uy = (h-pad) - (gauss(cl)/maxG)*cH;
  ctx.beginPath(); ctx.moveTo(ux, h-pad); ctx.lineTo(ux, uy);
  ctx.lineWidth = 1.5; ctx.strokeStyle = '#f59e0b'; ctx.setLineDash([3,3]); ctx.stroke(); ctx.setLineDash([]);
  ctx.beginPath(); ctx.arc(ux, uy, 5, 0, Math.PI*2); ctx.fillStyle = '#f59e0b'; ctx.fill();
  ctx.fillStyle = '#f59e0b'; ctx.font = `bold ${11*dpr/dpr}px var(--font-mono)`; ctx.textAlign = 'center';
  ctx.fillText('jij', ux, uy - 10);
}

interface Props { level: Level; onHome: () => void; onReplay: () => void; }

export default function Game1View({ level, onHome, onReplay }: Props) {
  const lvl = typeof level === 'number' ? level : 1;
  const total = lvl === 1 ? 5 : lvl === 2 ? 10 : 15;
  const [questions] = useState<Question[]>(() => generateQuestions(total, lvl));
  const [idx, setIdx] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [val, setVal] = useState('');
  const [flash, setFlash] = useState('');
  const [done, setDone] = useState(false);
  const [totalTime, setTotalTime] = useState(0);
  const startTime = useRef(Date.now());
  const timerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const inputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    timerRef.current = setInterval(() => setElapsed((Date.now()-startTime.current)/1000), 100);
    return () => clearInterval(timerRef.current);
  }, []);

  useEffect(() => { inputRef.current?.focus(); }, [idx]);

  useEffect(() => {
    if (done && canvasRef.current) {
      const avg = totalTime / total;
      setTimeout(() => drawBellCurve(canvasRef.current!, avg), 50);
    }
  }, [done, totalTime, total]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(val.trim());
    if (isNaN(num)) return;
    const q = questions[idx];
    const ok = Math.abs(num - q.answer) < 0.01;
    if (ok) setCorrect(c => c+1); else setWrong(w => w+1);
    setFlash(ok ? 'correct-flash' : 'wrong-flash');
    setTimeout(() => setFlash(''), 450);
    setVal('');
    if (idx + 1 >= total) {
      const tt = (Date.now()-startTime.current)/1000;
      clearInterval(timerRef.current);
      setTotalTime(tt);
      setDone(true);
      saveG1Stat({ date: Date.now(), level: lvl, accuracy: Math.round(((ok ? correct+1 : correct)/total)*100), avgTime: tt/total, correct: ok ? correct+1 : correct, total });
    } else { setIdx(i => i+1); }
  };

  const avgTime = done ? totalTime / total : 0;
  const accuracy = done ? Math.round((correct / total) * 100) : 0;
  const pctLabel = avgTime < 2 ? 'Top 5%' : avgTime < 3 ? 'Top 15%' : avgTime < 4.5 ? 'Gemiddeld' : avgTime < 6 ? 'Onder gemiddeld' : 'Langzaam';

  const card = (style?: React.CSSProperties) => ({
    backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)',
    borderRadius: 16, ...style,
  });

  if (done) return (
    <div style={{ maxWidth: 600, margin: '16px auto 0' }}>
      <div style={{ ...card({ padding: 28, borderRadius: 20 }) }}>
        <h3 style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 800, color: '#f59e0b', marginBottom: 4 }}>Analyse & Resultaten</h3>
        <p style={{ fontSize: 13, color: 'var(--color-muted)', marginBottom: 22 }}>Jouw prestatie vergeleken met de menselijke normaalverdeling.</p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 10, marginBottom: 20 }}>
          {[
            { label: 'Totaal Tijd', v: `${totalTime.toFixed(1)}s`, color: 'var(--color-text)' },
            { label: 'Gem. per Som', v: `${avgTime.toFixed(2)}s`, color: '#f59e0b' },
            { label: 'Goed / Fout', v: `${correct} / ${wrong}`, color: '#22c55e' },
            { label: 'Nauwkeurigheid', v: `${accuracy}%`, color: '#a855f7' },
          ].map(s => (
            <div key={s.label} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--color-border)', borderRadius: 12, padding: '12px 10px', textAlign: 'center' }}>
              <div style={{ fontSize: 11, color: 'var(--color-muted)', marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 17, fontWeight: 700, color: s.color }}>{s.v}</div>
            </div>
          ))}
        </div>

        <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid var(--color-border)', borderRadius: 12, padding: 16, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontSize: 11, color: 'var(--color-muted)', fontWeight: 600 }}>Menselijke Normaalverdeling</span>
            <span style={{ fontSize: 12, color: '#f59e0b', fontWeight: 700 }}>{pctLabel}</span>
          </div>
          <canvas ref={canvasRef} style={{ width: '100%', height: 130, display: 'block' }} />
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onReplay} style={{ flex: 1, padding: 12, borderRadius: 10, background: '#f59e0b', color: 'white', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>
            Opnieuw Spelen
          </button>
          <button onClick={onHome} style={{ padding: '12px 20px', borderRadius: 10, background: 'rgba(255,255,255,0.05)', color: 'var(--color-muted)', fontWeight: 600, fontSize: 13, border: '1px solid var(--color-border)', cursor: 'pointer' }}>
            Home
          </button>
        </div>
      </div>
    </div>
  );

  const q = questions[idx];
  return (
    <div style={{ maxWidth: 540, margin: '16px auto 0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', ...card({ padding: '12px 16px', marginBottom: 14 }) }}>
        <span style={{ fontSize: 13, color: 'var(--color-muted)', fontWeight: 600 }}>Som {idx+1} van {total}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color: '#f59e0b' }}>{elapsed.toFixed(1)}s</span>
      </div>

      <div style={{ height: 4, background: 'var(--color-border)', borderRadius: 2, marginBottom: 18, overflow: 'hidden' }}>
        <div style={{ height: '100%', background: '#f59e0b', width: `${(idx/total)*100}%`, transition: 'width 0.2s', borderRadius: 2 }} />
      </div>

      <div className={flash} style={{ ...card({ border: '2px solid var(--color-border)', borderRadius: 20, padding: '36px 28px', textAlign: 'center', marginBottom: 12 }) }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#f59e0b', marginBottom: 14 }}>
          {q.label}
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 44, fontWeight: 800, color: 'var(--color-text)', marginBottom: 28 }}>
          {q.text}
        </div>
        <form onSubmit={submit}>
          <input
            ref={inputRef} type="number" value={val} onChange={e => setVal(e.target.value)}
            placeholder="Vul ? in" step="any" autoComplete="off"
            style={{
              width: '100%', textAlign: 'center', background: 'rgba(255,255,255,0.04)',
              border: '2px solid rgba(255,255,255,0.1)', borderRadius: 12,
              padding: '13px 16px', fontFamily: 'var(--font-mono)', fontSize: 24, fontWeight: 700,
              color: 'var(--color-text)', outline: 'none', transition: 'border-color 0.15s',
            }}
            onFocus={e => e.target.style.borderColor = '#f59e0b'}
            onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
          />
          <input type="submit" style={{ display: 'none' }} />
        </form>
      </div>

      <div style={{ textAlign: 'center', fontSize: 12, color: 'var(--color-muted)' }}>
        Druk op{' '}
        <kbd style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid var(--color-border)', padding: '2px 8px', borderRadius: 4, fontFamily: 'var(--font-mono)', fontSize: 11 }}>
          Enter
        </kbd>{' '}
        om te bevestigen
      </div>
    </div>
  );
}
