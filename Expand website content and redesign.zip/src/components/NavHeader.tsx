import type { ViewId, FontMode, ThemeMode } from '../types';

interface Props {
  currentView: ViewId;
  onHome: () => void;
  onNavigate: (v: ViewId) => void;
  font: FontMode;
  setFont: (f: FontMode) => void;
  theme: ThemeMode;
  setTheme: (t: ThemeMode) => void;
}

const NAV: { label: string; view: ViewId }[] = [
  { label: 'Spellen', view: 'hub' },
  { label: 'Theorie', view: 'theorie' },
  { label: 'Formules', view: 'formules' },
  { label: 'Voortgang', view: 'voortgang' },
];

const S = {
  header: {
    background: 'var(--nav-bg)',
    borderBottom: '1px solid var(--color-border)',
    backdropFilter: 'blur(16px)',
    WebkitBackdropFilter: 'blur(16px)',
    position: 'sticky' as const,
    top: 0, zIndex: 50,
  },
  inner: {
    maxWidth: 1100, margin: '0 auto', padding: '10px 20px',
    display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
  },
  logo: {
    display: 'flex', alignItems: 'center', gap: 10,
    background: 'none', border: 'none', cursor: 'pointer', padding: 0,
  },
  logoMark: {
    width: 36, height: 36, borderRadius: 10, flexShrink: 0,
    background: 'linear-gradient(135deg, #6366f1, #a855f7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--font-mono)', fontWeight: 800, fontSize: 17, color: 'white',
  },
  logoText: { fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 14, color: 'var(--color-text)', letterSpacing: '-0.02em' },
  logoSub: { fontSize: 11, color: 'var(--color-muted)', fontWeight: 500, lineHeight: 1 },
  nav: { display: 'flex', alignItems: 'center', gap: 2 } as React.CSSProperties,
  pill: {
    display: 'flex', alignItems: 'center', gap: 2,
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid var(--color-border)',
    borderRadius: 9, padding: 3,
  },
};

function navBtnStyle(active: boolean) {
  return {
    padding: '5px 13px', borderRadius: 7, fontSize: 13, fontWeight: 600,
    color: active ? '#818cf8' : 'var(--color-muted)',
    backgroundColor: active ? 'rgba(99,102,241,0.12)' : 'transparent',
    border: active ? '1px solid rgba(99,102,241,0.25)' : '1px solid transparent',
    cursor: 'pointer', transition: 'all 0.15s',
  };
}

function pillBtnStyle(active: boolean, activeColor?: string) {
  return {
    padding: '3px 9px', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', transition: 'all 0.15s',
    backgroundColor: active ? (activeColor ? `${activeColor}20` : 'rgba(255,255,255,0.1)') : 'transparent',
    color: active ? (activeColor || 'var(--color-text)') : 'var(--color-muted)',
    border: active ? `1px solid ${activeColor ? `${activeColor}40` : 'rgba(255,255,255,0.15)'}` : '1px solid transparent',
  };
}

import React from 'react';

export default function NavHeader({ currentView, onHome, onNavigate, font, setFont, theme, setTheme }: Props) {
  const isGame = ['game1', 'game2', 'game3'].includes(currentView);

  return (
    <header style={S.header}>
      <div style={S.inner}>
        <button style={S.logo} onClick={onHome} aria-label="Home">
          <div style={S.logoMark}>∑</div>
          <div>
            <div style={S.logoText}>Math & Reken Hub</div>
            <div style={S.logoSub}>VWO & HAVO</div>
          </div>
        </button>

        <nav style={S.nav} className="hidden md:flex">
          {NAV.map(n => (
            <button key={n.view} onClick={() => onNavigate(n.view)} style={navBtnStyle(currentView === n.view || (n.view === 'hub' && isGame))}>
              {n.label}
            </button>
          ))}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={S.pill}>
            <button onClick={() => setFont('outfit')} style={pillBtnStyle(font === 'outfit', '#818cf8')} title="Standaard font">Aa</button>
            <button onClick={() => setFont('lexend')} style={pillBtnStyle(font === 'lexend', '#818cf8')} title="Lexend (leesbaarder)">Lex</button>
            <button onClick={() => setFont('dyslexic')} style={pillBtnStyle(font === 'dyslexic', '#818cf8')} title="OpenDyslexic">♿</button>
          </div>
          <div style={S.pill}>
            <button onClick={() => setTheme('dark')} style={pillBtnStyle(theme === 'dark')} title="Donker">🌙</button>
            <button onClick={() => setTheme('light')} style={pillBtnStyle(theme === 'light')} title="Licht">☀️</button>
            <button onClick={() => setTheme('oled')} style={pillBtnStyle(theme === 'oled')} title="OLED">🖤</button>
          </div>
        </div>
      </div>
    </header>
  );
}
