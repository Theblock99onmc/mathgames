import type { GameId, ViewId } from '../types';

interface Props {
  onSelectGame: (g: GameId) => void;
  onNavigate: (v: ViewId) => void;
}

const GAMES = [
  {
    id: 'rekensnelheid' as GameId,
    icon: '⚡',
    title: 'RekenSnelheid',
    tag: 'Snelheid & Accuraatheid',
    color: '#f59e0b',
    colorBg: 'rgba(245,158,11,0.08)',
    colorBorder: 'rgba(245,158,11,0.22)',
    description: 'Los rekenopgaven op zo snel mogelijk en vergelijk je score met de menselijke normaalverdeling. Hoe snel ben jij?',
    details: ['Optellen, aftrekken, vermenigvuldigen & kwadraten', 'Tijdmeting per opgave', 'Klokkurve & percentielanalyse na afloop'],
    btn: 'Start RekenSnelheid',
  },
  {
    id: 'peeler' as GameId,
    icon: '🧅',
    title: 'Math Peeler',
    tag: 'Algebraïsch Inzicht',
    color: '#a855f7',
    colorBg: 'rgba(168,85,247,0.08)',
    colorBorder: 'rgba(168,85,247,0.22)',
    description: 'Pel wiskundige formules laag voor laag af. Herken de buitenste bewerking en verwijder hem — van buiten naar binnen. Met ♾️ Infinite Mode!',
    details: ['+, −, ×, ÷, machten en wortels', 'Lagen systeem met visuele MathJax weergave', 'Infinite Mode met persoonlijke highscore'],
    btn: 'Start Math Peeler',
  },
  {
    id: 'verhaaltjes' as GameId,
    icon: '📖',
    title: 'Verhaaltjessommen',
    tag: 'Contextueel Rekenen',
    color: '#10b981',
    colorBg: 'rgba(16,185,129,0.08)',
    colorBorder: 'rgba(16,185,129,0.22)',
    description: 'Vertaal verhalen en situaties naar wiskundige oplossingen. Essentieel voor toepassingsvragen op het VO-examen.',
    details: ['3 moeilijkheidsniveaus (basis t/m gevorderd)', 'Stap-voor-stap uitleg bij elk antwoord', 'Hintfunctie voor als je vastloopt'],
    btn: 'Start Verhaaltjes',
  },
];

const EXTRAS = [
  {
    view: 'theorie' as ViewId,
    icon: '📚',
    title: 'Theorie & Uitleg',
    color: '#818cf8',
    colorBg: 'rgba(99,102,241,0.08)',
    colorBorder: 'rgba(99,102,241,0.22)',
    description: 'Beknopte uitleg per wiskundeonderwerp met voorbeeldopgaven en stap-voor-stap oplossingen.',
  },
  {
    view: 'formules' as ViewId,
    icon: '📐',
    title: 'Formuleboek',
    color: '#22d3ee',
    colorBg: 'rgba(6,182,212,0.08)',
    colorBorder: 'rgba(6,182,212,0.22)',
    description: 'Alle basisformules op één plek. Algebra, meetkunde en statistiek — doorzoekbaar en gecategoriseerd.',
  },
  {
    view: 'voortgang' as ViewId,
    icon: '📊',
    title: 'Mijn Voortgang',
    color: '#fb7185',
    colorBg: 'rgba(244,63,94,0.08)',
    colorBorder: 'rgba(244,63,94,0.22)',
    description: 'Bekijk je eigen statistieken: gespeelde spellen, nauwkeurigheid, persoonlijke records en meer.',
  },
];

const STEPS = [
  { n: '01', title: 'Kies een spel', text: 'Selecteer RekenSnelheid, Math Peeler of Verhaaltjessommen.' },
  { n: '02', title: 'Stel niveau in', text: 'Kies niveau 1, 2 of 3 — of ga direct voor Infinite Mode.' },
  { n: '03', title: 'Oefen actief', text: 'Los opgaven op en krijg directe feedback op je antwoorden.' },
  { n: '04', title: 'Analyse je resultaten', text: 'Zie je score, nauwkeurigheid en vergelijk met de normaalverdeling.' },
];

function SectionLabel({ n, label }: { n: string; label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--color-muted)' }}>
        {n} — {label}
      </span>
      <div style={{ flex: 1, height: 1, background: 'var(--color-border)' }} />
    </div>
  );
}

export default function HubView({ onSelectGame, onNavigate }: Props) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 48 }}>

      {/* Hero */}
      <section style={{ paddingTop: 16 }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '4px 12px', background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.25)',
          borderRadius: 99, fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
          color: 'var(--color-primary-light)', marginBottom: 16,
        }}>
          ◆ Oefen & Verbeter
        </div>
        <h1 style={{
          fontFamily: 'var(--font-mono)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.1,
          fontSize: 'clamp(30px, 5vw, 50px)', color: 'var(--color-text)', marginBottom: 16,
        }}>
          Kies je<br />
          <span style={{ background: 'linear-gradient(90deg, #6366f1 0%, #a855f7 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            rekenuitdaging
          </span>
        </h1>
        <p style={{ fontSize: 15, color: 'var(--color-muted)', lineHeight: 1.75, maxWidth: 520 }}>
          Verbeter je rekenvaardigheid, algebraïsch inzicht en probleemoplossend denken.
          Drie interactieve spellen, uitgebreide theorie, en een volledig formuleboek — alles op één platform voor VWO & HAVO leerlingen.
        </p>
      </section>

      {/* Games */}
      <section>
        <SectionLabel n="01" label="Oefenspellen" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {GAMES.map(g => (
            <div key={g.id} style={{
              backgroundColor: 'var(--color-surface)', border: `1px solid ${g.colorBorder}`,
              borderRadius: 18, padding: 24, display: 'flex', flexDirection: 'column', gap: 14,
              transition: 'transform 0.18s, box-shadow 0.18s',
            }}
              onMouseOver={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-3px)'; (e.currentTarget as HTMLElement).style.boxShadow = `0 12px 32px ${g.colorBg}`; }}
              onMouseOut={e => { (e.currentTarget as HTMLElement).style.transform = 'none'; (e.currentTarget as HTMLElement).style.boxShadow = 'none'; }}
            >
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                <div style={{
                  width: 46, height: 46, background: g.colorBg, border: `1px solid ${g.colorBorder}`,
                  borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0,
                }}>{g.icon}</div>
                <span style={{
                  fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase',
                  color: g.color, background: g.colorBg, border: `1px solid ${g.colorBorder}`,
                  padding: '3px 8px', borderRadius: 6,
                }}>{g.tag}</span>
              </div>

              <div>
                <h3 style={{ fontFamily: 'var(--font-mono)', fontSize: 19, fontWeight: 700, color: 'var(--color-text)', marginBottom: 8 }}>
                  {g.title}
                </h3>
                <p style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.65 }}>{g.description}</p>
              </div>

              <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 5 }}>
                {g.details.map((d, i) => (
                  <li key={i} style={{ fontSize: 12, color: 'var(--color-muted)', display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                    <span style={{ width: 4, height: 4, borderRadius: '50%', background: g.color, flexShrink: 0, marginTop: 6 }} />
                    {d}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => onSelectGame(g.id)}
                style={{
                  marginTop: 'auto', padding: '10px 16px', borderRadius: 10,
                  background: g.color, color: 'white', fontWeight: 700, fontSize: 13,
                  border: 'none', cursor: 'pointer', transition: 'filter 0.15s',
                }}
                onMouseOver={e => (e.currentTarget.style.filter = 'brightness(0.88)')}
                onMouseOut={e => (e.currentTarget.style.filter = 'none')}
              >
                {g.btn}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Extras */}
      <section>
        <SectionLabel n="02" label="Leer & Naslag" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 12 }}>
          {EXTRAS.map(e => (
            <button
              key={e.view}
              onClick={() => onNavigate(e.view)}
              style={{
                backgroundColor: 'var(--color-surface)', border: `1px solid ${e.colorBorder}`,
                borderRadius: 16, padding: 22, textAlign: 'left', cursor: 'pointer',
                transition: 'transform 0.18s', background: 'var(--color-surface)',
              }}
              onMouseOver={el => (el.currentTarget.style.transform = 'translateY(-2px)')}
              onMouseOut={el => (el.currentTarget.style.transform = 'none')}
            >
              <div style={{
                width: 40, height: 40, background: e.colorBg, border: `1px solid ${e.colorBorder}`,
                borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 20, marginBottom: 14,
              }}>{e.icon}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: 700, color: 'var(--color-text)', marginBottom: 8 }}>{e.title}</div>
              <div style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.6, marginBottom: 14 }}>{e.description}</div>
              <div style={{ fontSize: 12, color: e.color, fontWeight: 600 }}>Bekijk →</div>
            </button>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section>
        <SectionLabel n="03" label="Hoe het werkt" />
        <div style={{
          background: 'var(--color-surface)', border: '1px solid var(--color-border)',
          borderRadius: 16, padding: '28px 24px',
          display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 24,
        }}>
          {STEPS.map(s => (
            <div key={s.n}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 26, fontWeight: 800, color: 'rgba(99,102,241,0.25)', marginBottom: 10 }}>{s.n}</div>
              <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--color-text)', marginBottom: 6 }}>{s.title}</div>
              <div style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.65 }}>{s.text}</div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
