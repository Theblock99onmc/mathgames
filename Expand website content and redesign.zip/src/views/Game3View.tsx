import { useState, useEffect, useRef } from 'react';
import type { Level } from '../types';
import { saveG3Stat } from '../utils/stats';

interface Q { story: string; answer: number; unit: string; hint: string; explanation: string; }

const BANK: Record<number, Q[]> = {
  1: [
    { story: "Een jas kost €80. Tijdens de uitverkoop krijg je 25% korting. Hoeveel euro moet je nu betalen voor de jas?", answer: 60, unit: "euro", hint: "Bereken eerst 25% van 80 (= 80 ÷ 4) en trek dat af van 80.", explanation: "25% van €80 = €20. Dus de jas kost €80 − €20 = €60." },
    { story: "Een taartrecept voor 4 personen heeft 200 gram suiker nodig. Je wilt taart maken voor 10 personen. Hoeveel gram suiker heb je nodig?", answer: 500, unit: "gram", hint: "Bereken hoeveel suiker per persoon nodig is (200 ÷ 4) en vermenigvuldig met 10.", explanation: "Per persoon: 200 ÷ 4 = 50 gram. Voor 10 personen: 50 × 10 = 500 gram." },
    { story: "Op een school met 400 leerlingen komt 60% op de fiets. Hoeveel leerlingen komen er op de fiets?", answer: 240, unit: "leerlingen", hint: "10% van 400 is 40. Vermenigvuldig 40 met 6 om 60% te berekenen.", explanation: "10% = 40. 60% = 6 × 40 = 240 leerlingen." },
  ],
  2: [
    { story: "Sanne fietst met een gemiddelde snelheid van 18 km/u. Hoeveel kilometer legt zij af in 40 minuten?", answer: 12, unit: "km", hint: "40 minuten is 2/3 van een uur. Vermenigvuldig 18 × (40 ÷ 60).", explanation: "40 min = 2/3 uur. Afstand = 18 × (2/3) = 12 km." },
    { story: "Een rechthoekig schoolplein van 25 meter lang en 16 meter breed wordt opnieuw betegeld. Tegels kosten €10 per m². Wat zijn de totale tegelkosten?", answer: 4000, unit: "euro", hint: "Bereken eerst de oppervlakte (25 × 16) en vermenigvuldig met €10 per m².", explanation: "Oppervlakte = 25 × 16 = 400 m². Kosten = 400 × 10 = €4000." },
    { story: "Een aquarium is 80 cm lang, 50 cm breed en 40 cm hoog. Hoeveel liter water past er in?", answer: 160, unit: "liter", hint: "Zet cm om naar dm: 8 × 5 × 4. Dan geldt 1 dm³ = 1 liter.", explanation: "8 dm × 5 dm × 4 dm = 160 dm³ = 160 liter." },
  ],
  3: [
    { story: "Abonnement A kost €15 per maand plus €0,10 per MB. Abonnement B kost €25 per maand met onbeperkt internet. Bij hoeveel MB zijn beide abonnementen even duur?", answer: 100, unit: "MB", hint: "Stel de vergelijking op: 15 + 0,10 × MB = 25.", explanation: "15 + 0,10 × MB = 25 → 0,10 × MB = 10 → MB = 100." },
    { story: "Daan is 3 jaar ouder dan Sophie. Samen zijn zij 31 jaar oud. Hoe oud is Daan?", answer: 17, unit: "jaar", hint: "Als Sophie x jaar is, is Daan (x + 3). Dan geldt: x + (x + 3) = 31.", explanation: "2x + 3 = 31 → 2x = 28 → x = 14 (Sophie). Daan = 14 + 3 = 17 jaar." },
    { story: "Een winkelier verhoogt de prijs van een laptop met 20%. Een maand later geeft hij 20% korting op de nieuwe prijs. De originele prijs was €500. Wat is de eindprijs?", answer: 480, unit: "euro", hint: "Bereken eerst +20% van 500, dan −20% van die nieuwe waarde.", explanation: "500 + 20% = €600. Korting 20% van €600 = €120. Eindprijs = €600 − €120 = €480." },
  ],
};

interface Props { level: Level; onHome: () => void; onReplay: () => void; }

export default function Game3View({ level, onHome, onReplay }: Props) {
  const lvl = typeof level === 'number' ? Math.min(Math.max(level, 1), 3) : 1;
  const qs = BANK[lvl];
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [val, setVal] = useState('');
  const [hint, setHint] = useState(false);
  const [feedback, setFeedback] = useState<{ ok: boolean; exp: string; ans: number } | null>(null);
  const [done, setDone] = useState(false);
  const [totalTime, setTotalTime] = useState(0);
  const startTime = useRef(Date.now());
  const timerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    timerRef.current = setInterval(() => setElapsed((Date.now()-startTime.current)/1000), 100);
    return () => clearInterval(timerRef.current);
  }, []);

  useEffect(() => { if (!feedback) inputRef.current?.focus(); }, [idx, feedback]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(val.replace(',', '.').trim());
    if (isNaN(num)) return;
    const q = qs[idx];
    const ok = Math.abs(num - q.answer) < 0.01;
    if (ok) setScore(s => s + 1);
    setFeedback({ ok, exp: q.explanation, ans: q.answer });
  };

  const next = () => {
    if (idx + 1 >= qs.length) {
      const tt = (Date.now() - startTime.current) / 1000;
      clearInterval(timerRef.current);
      setTotalTime(tt);
      setDone(true);
      saveG3Stat({ date: Date.now(), level: lvl, score: feedback?.ok ? score + 1 : score, total: qs.length, time: tt });
    } else {
      setIdx(i => i + 1); setFeedback(null); setHint(false); setVal('');
    }
  };

  const card = { backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 16 };

  if (done) return (
    <div style={{ maxWidth: 460, margin: '32px auto 0' }}>
      <div style={{ ...card, borderRadius: 20, padding: 32, textAlign: 'center' }}>
        <div style={{ fontSize: 44, marginBottom: 8 }}>🎉</div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 24, fontWeight: 800, color: '#10b981', marginBottom: 20 }}>Ronde Voltooid!</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
          <div style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 12, padding: 16 }}>
            <div style={{ fontSize: 12, color: 'var(--color-muted)', marginBottom: 4 }}>Score</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 30, fontWeight: 800, color: '#10b981' }}>{score} / {qs.length}</div>
          </div>
          <div style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 12, padding: 16 }}>
            <div style={{ fontSize: 12, color: 'var(--color-muted)', marginBottom: 4 }}>Totale Tijd</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 30, fontWeight: 800, color: '#818cf8' }}>{totalTime.toFixed(1)}s</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onReplay} style={{ flex: 1, padding: 12, borderRadius: 10, background: '#10b981', color: 'white', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>Opnieuw</button>
          <button onClick={onHome} style={{ padding: '12px 20px', borderRadius: 10, background: 'rgba(255,255,255,0.05)', color: 'var(--color-muted)', fontWeight: 600, fontSize: 13, border: '1px solid var(--color-border)', cursor: 'pointer' }}>Home</button>
        </div>
      </div>
    </div>
  );

  const q = qs[idx];
  return (
    <div style={{ maxWidth: 600, margin: '16px auto 0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', ...card, padding: '12px 16px', marginBottom: 14 }}>
        <span style={{ fontSize: 13, color: 'var(--color-muted)', fontWeight: 600 }}>Vraag {idx+1} van {qs.length}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color: '#10b981' }}>{elapsed.toFixed(1)}s</span>
      </div>

      <div style={{ height: 4, background: 'var(--color-border)', borderRadius: 2, marginBottom: 18, overflow: 'hidden' }}>
        <div style={{ height: '100%', background: '#10b981', width: `${(idx/qs.length)*100}%`, transition: 'width 0.2s', borderRadius: 2 }} />
      </div>

      <div style={{ ...card, border: '2px solid var(--color-border)', borderRadius: 20, padding: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, paddingBottom: 14, borderBottom: '1px solid var(--color-border)' }}>
          <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#10b981', background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.25)', padding: '3px 8px', borderRadius: 6 }}>
            Contextueel
          </span>
          <button onClick={() => setHint(h => !h)} style={{ fontSize: 12, color: '#f59e0b', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>
            💡 {hint ? 'Verberg hint' : 'Hint nodig?'}
          </button>
        </div>

        <p style={{ fontSize: 15, lineHeight: 1.75, color: 'var(--color-text)', marginBottom: 16, fontWeight: 500 }}>{q.story}</p>

        {hint && (
          <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.25)', borderRadius: 10, padding: 12, marginBottom: 16, fontSize: 13, color: '#fbbf24', lineHeight: 1.6 }}>
            💡 {q.hint}
          </div>
        )}

        {!feedback && (
          <form onSubmit={submit}>
            <div style={{ display: 'flex', gap: 10, marginBottom: 12 }}>
              <input
                ref={inputRef} type="number" value={val} onChange={e => setVal(e.target.value)}
                placeholder="Jouw antwoord..." step="any" autoComplete="off"
                style={{
                  flex: 1, background: 'rgba(255,255,255,0.04)', border: '2px solid rgba(255,255,255,0.1)',
                  borderRadius: 12, padding: '12px 16px', fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700,
                  color: 'var(--color-text)', outline: 'none', transition: 'border-color 0.15s',
                }}
                onFocus={e => e.target.style.borderColor = '#10b981'}
                onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
              />
              <span style={{ display: 'flex', alignItems: 'center', padding: '0 16px', background: 'rgba(255,255,255,0.04)', border: '1px solid var(--color-border)', borderRadius: 12, fontSize: 13, fontWeight: 600, color: 'var(--color-muted)', whiteSpace: 'nowrap' }}>
                {q.unit}
              </span>
            </div>
            <button type="submit" style={{ width: '100%', padding: 12, borderRadius: 10, background: '#10b981', color: 'white', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>
              Controleer Antwoord
            </button>
          </form>
        )}

        {feedback && (
          <div style={{ background: feedback.ok ? 'rgba(34,197,94,0.08)' : 'rgba(239,68,68,0.08)', border: `1px solid ${feedback.ok ? 'rgba(34,197,94,0.25)' : 'rgba(239,68,68,0.25)'}`, borderRadius: 12, padding: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: feedback.ok ? '#22c55e' : '#f87171', marginBottom: 8 }}>
              {feedback.ok ? '✅ Goed Antwoord!' : `❌ Helaas, het juiste antwoord was ${feedback.ans} ${q.unit}`}
            </div>
            <p style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.65, marginBottom: 14 }}>{feedback.exp}</p>
            <button onClick={next} style={{ padding: '8px 16px', borderRadius: 8, background: 'rgba(255,255,255,0.08)', color: 'var(--color-text)', fontWeight: 700, fontSize: 12, border: '1px solid var(--color-border)', cursor: 'pointer' }}>
              Volgende Vraag →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
