import { useState, useEffect } from 'react';
import type { ViewId, GameId, Level, FontMode, ThemeMode } from './types';
import NavHeader from './components/NavHeader';
import HubView from './views/HubView';
import SetupView from './views/SetupView';
import Game1View from './views/Game1View';
import Game2View from './views/Game2View';
import Game3View from './views/Game3View';
import TheorieView from './views/TheorieView';
import FormulesView from './views/FormulesView';
import VoortgangView from './views/VoortgangView';

export default function App() {
  const [view, setView] = useState<ViewId>('hub');
  const [game, setGame] = useState<GameId | null>(null);
  const [level, setLevel] = useState<Level>(1);
  const [font, setFont] = useState<FontMode>('outfit');
  const [theme, setTheme] = useState<ThemeMode>('dark');

  useEffect(() => {
    const f = (localStorage.getItem('math_hub_font') as FontMode) || 'outfit';
    const t = (localStorage.getItem('math_hub_theme') as ThemeMode) || 'dark';
    setFont(f); setTheme(t);
  }, []);

  useEffect(() => {
    document.body.classList.remove('font-lexend', 'font-dyslexic');
    if (font === 'lexend') document.body.classList.add('font-lexend');
    if (font === 'dyslexic') document.body.classList.add('font-dyslexic');
    localStorage.setItem('math_hub_font', font);
  }, [font]);

  useEffect(() => {
    const html = document.documentElement;
    html.classList.remove('light', 'oled');
    if (theme === 'light') html.classList.add('light');
    else if (theme === 'oled') html.classList.add('oled');
    localStorage.setItem('math_hub_theme', theme);
  }, [theme]);

  const goHome = () => setView('hub');

  const selectGame = (g: GameId) => { setGame(g); setView('setup'); };

  const selectLevel = (l: Level) => {
    setLevel(l);
    if (game === 'rekensnelheid') setView('game1');
    else if (game === 'peeler') setView('game2');
    else if (game === 'verhaaltjes') setView('game3');
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
      <NavHeader currentView={view} onHome={goHome} onNavigate={setView} font={font} setFont={setFont} theme={theme} setTheme={setTheme} />
      <main style={{ flex: 1, maxWidth: 1100, margin: '0 auto', width: '100%', padding: '24px 20px 48px' }}>
        {view === 'hub'      && <HubView onSelectGame={selectGame} onNavigate={setView} />}
        {view === 'setup'    && <SetupView game={game!} onSelectLevel={selectLevel} onBack={goHome} />}
        {view === 'game1'    && <Game1View key={`g1-${level}`} level={level} onHome={goHome} onReplay={() => selectGame('rekensnelheid')} />}
        {view === 'game2'    && <Game2View key={`g2-${level}`} level={level} onHome={goHome} onReplay={() => selectGame('peeler')} />}
        {view === 'game3'    && <Game3View key={`g3-${level}`} level={level} onHome={goHome} onReplay={() => selectGame('verhaaltjes')} />}
        {view === 'theorie'  && <TheorieView onHome={goHome} />}
        {view === 'formules' && <FormulesView onHome={goHome} />}
        {view === 'voortgang'&& <VoortgangView onHome={goHome} />}
      </main>
      <footer style={{ borderTop: '1px solid var(--color-border)', padding: '14px 0', textAlign: 'center', fontSize: 12, color: 'var(--color-muted)' }}>
        Math & Reken Hub © 2026 · Wiskunde & Rekenen · VWO & HAVO Platform
      </footer>
    </div>
  );
}
