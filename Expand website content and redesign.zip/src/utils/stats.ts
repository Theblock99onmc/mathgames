export interface G1Stat { date: number; level: number; accuracy: number; avgTime: number; correct: number; total: number; }
export interface G2Stat { date: number; level: number | string; time: number; score: number; infinite: boolean; newHs: boolean; }
export interface G3Stat { date: number; level: number; score: number; total: number; time: number; }

interface AllStats { g1: G1Stat[]; g2: G2Stat[]; g3: G3Stat[]; }

const KEY = 'math_hub_stats';
const MAX = 50;

function load(): AllStats {
  try { return JSON.parse(localStorage.getItem(KEY) || '{"g1":[],"g2":[],"g3":[]}'); }
  catch { return { g1: [], g2: [], g3: [] }; }
}

function save(s: AllStats) {
  s.g1 = s.g1.slice(-MAX); s.g2 = s.g2.slice(-MAX); s.g3 = s.g3.slice(-MAX);
  localStorage.setItem(KEY, JSON.stringify(s));
}

export const saveG1Stat = (s: G1Stat) => { const d = load(); d.g1.push(s); save(d); };
export const saveG2Stat = (s: G2Stat) => { const d = load(); d.g2.push(s); save(d); };
export const saveG3Stat = (s: G3Stat) => { const d = load(); d.g3.push(s); save(d); };
export const getStats = (): AllStats => load();
export const clearStats = () => localStorage.removeItem(KEY);
