import { useState, useCallback } from 'react';
import { getStats, clearStats } from '../utils/stats';
import type { G1Stat, G2Stat, G3Stat } from '../utils/stats';

interface Props { onHome: () => void; }

function fmtDate(ts: number) {
  return new Date(ts).toLocaleDateString('nl-NL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function Bar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div style={{ height: 6, background: 'rgba(255,255,255,0.06)', borderRadius: 3, overflow: 'hidden' }}>
      <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 3, transition: 'width 0.5s ease' }} />
    </div>
  );
}

function StatCard({ label, value, color, sub }: { label: string; value: string; color: string; sub?: string }) {
  return (
    <div style={{ background: 'var(--color-surface-2)', border: '1px solid var(--color-border)', borderRadius: 12, padding: '14px 16px' }}>
      <div style={{ fontSize: 11, color: 'var(--color-muted)', marginBottom: 4 }}>{label}</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 800, color }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--color-muted)', marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

export default function VoortgangView({ onHome }: Props) {
  const [stats, setStats] = useState(() => getStats());
  const [confirmClear, setConfirmClear] = useState(false);

  const doReset = useCallback(() => { clearStats(); setStats(getStats()); setConfirmClear(false); }, []);

  const { g1, g2, g3 } = stats;
  const totalGames = g1.length + g2.length + g3.length;
  const g1Avg = g1.length ? g1.reduce((s, x) => s + x.accuracy, 0) / g1.length : 0;
  const g3Avg = g3.length ? g3.reduce((s, x) => s + (x.score/x.total)*100, 0) / g3.length : 0;
  const g2BestInf = g2.filter(x => x.infinite).reduce((best, x) => Math.max(best, x.score), 0);
  const g1Best = g1.length ? g1.reduce((b, x) => x.avgTime < b.avgTime ? x : b) : null;

  const recentAll: { type: string; label: string; color: string; summary: string; date: number }[] = [
    ...g1.map(x => ({ type: 'G1', label: 'RekenSnelheid', color: '#f59e0b', summary: `Niv. ${x.level} · ${x.accuracy}% · ${x.avgTime.toFixed(2)}s/som`, date: x.date })),
    ...g2.map(x => ({ type: 'G2', label: 'Math Peeler', color: '#a855f7', summary: x.infinite ? `Infinite · Score ${x.score}` : `Niv. ${x.level} · ${x.time.toFixed(1)}s`, date: x.date })),
    ...g3.map(x => ({ type: 'G3', label: 'Verhaaltjessommen', color: '#10b981', summary: `Niv. ${x.level} · ${x.score}/${x.total} goed`, date: x.date })),
  ].sort((a, b) => b.date - a.date).slice(0, 15);

  return (
    <div style={{ maxWidth: 780, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <div style={{ width: 38, height: 38, background: 'rgba(244,63,94,0.12)', border: '1px solid rgba(244,63,94,0.25)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>📊</div>
          <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 800, color: 'var(--color-text)' }}>Mijn Voortgang</h1>
        </div>
        <p style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.7 }}>
          Je statistieken worden lokaal opgeslagen in deze browser. Speel meer spellen om je voortgang bij te houden.
        </p>
      </div>

      {totalGames === 0 ? (
        <div style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 16, padding: 40, textAlign: 'center' }}>
          <div style={{ fontSize: 44, marginBottom: 12 }}>🎯</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 700, color: 'var(--color-text)', marginBottom: 8 }}>Nog geen spellen gespeeld</div>
          <p style={{ fontSize: 13, color: 'var(--color-muted)', marginBottom: 20, maxWidth: 380, margin: '0 auto 20px' }}>
            Ga naar de homepage en speel je eerste spel. Je statistieken verschijnen hier zodra je een ronde voltooit.
          </p>
          <button onClick={onHome} style={{ padding: '10px 24px', borderRadius: 10, background: '#6366f1', color: 'white', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>
            Naar Spellen →
          </button>
        </div>
      ) : (
        <>
          {/* Overview */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10, marginBottom: 24 }}>
            <StatCard label="Spellen Gespeeld" value={String(totalGames)} color="#818cf8" />
            <StatCard label="RekenSnelheid" value={g1.length > 0 ? `${Math.round(g1Avg)}%` : '—'} color="#f59e0b" sub={g1.length > 0 ? `${g1.length} spellen` : 'Nog niet gespeeld'} />
            <StatCard label="Verhaaltjes Gem." value={g3.length > 0 ? `${Math.round(g3Avg)}%` : '—'} color="#10b981" sub={g3.length > 0 ? `${g3.length} spellen` : 'Nog niet gespeeld'} />
            <StatCard label="Peeler High Score" value={g2BestInf > 0 ? String(g2BestInf) : '—'} color="#a855f7" sub="Infinite Mode" />
          </div>

          {/* Per game stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12, marginBottom: 24 }}>

            {/* Game 1 */}
            {g1.length > 0 && (
              <div style={{ backgroundColor: 'var(--color-surface)', border: '1px solid rgba(245,158,11,0.22)', borderRadius: 16, padding: 20 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
                  <span style={{ fontSize: 20 }}>⚡</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 14, color: '#f59e0b' }}>RekenSnelheid</span>
                  <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--color-muted)' }}>{g1.length}×</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--color-muted)', marginBottom: 5 }}>
                      <span>Gem. nauwkeurigheid</span><span style={{ color: '#f59e0b', fontWeight: 700 }}>{Math.round(g1Avg)}%</span>
                    </div>
                    <Bar value={g1Avg} max={100} color="#f59e0b" />
                  </div>
                  {g1Best && (
                    <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>
                      Beste tijd: <span style={{ color: '#f59e0b', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{g1Best.avgTime.toFixed(2)}s</span> per som
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Game 2 */}
            {g2.length > 0 && (
              <div style={{ backgroundColor: 'var(--color-surface)', border: '1px solid rgba(168,85,247,0.22)', borderRadius: 16, padding: 20 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
                  <span style={{ fontSize: 20 }}>🧅</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 14, color: '#a855f7' }}>Math Peeler</span>
                  <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--color-muted)' }}>{g2.length}×</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {g2BestInf > 0 && (
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--color-muted)', marginBottom: 5 }}>
                        <span>Beste Infinite score</span><span style={{ color: '#a855f7', fontWeight: 700, fontFamily: 'var(--font-mono)' }}>{g2BestInf}</span>
                      </div>
                      <Bar value={g2BestInf} max={Math.max(50, g2BestInf)} color="#a855f7" />
                    </div>
                  )}
                  <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>
                    Beste normale tijd: <span style={{ color: '#a855f7', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>
                      {g2.filter(x => !x.infinite).length > 0
                        ? `${Math.min(...g2.filter(x => !x.infinite).map(x => x.time)).toFixed(1)}s`
                        : '—'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Game 3 */}
            {g3.length > 0 && (
              <div style={{ backgroundColor: 'var(--color-surface)', border: '1px solid rgba(16,185,129,0.22)', borderRadius: 16, padding: 20 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
                  <span style={{ fontSize: 20 }}>📖</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 14, color: '#10b981' }}>Verhaaltjessommen</span>
                  <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--color-muted)' }}>{g3.length}×</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--color-muted)', marginBottom: 5 }}>
                      <span>Gem. score</span><span style={{ color: '#10b981', fontWeight: 700 }}>{Math.round(g3Avg)}%</span>
                    </div>
                    <Bar value={g3Avg} max={100} color="#10b981" />
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>
                    Beste score: <span style={{ color: '#10b981', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>
                      {Math.max(...g3.map(x => x.score))}/{g3[0].total}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Recent sessions */}
          {recentAll.length > 0 && (
            <div style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 16, padding: 20, marginBottom: 20 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--color-muted)', marginBottom: 14 }}>
                Recente Sessies
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {recentAll.map((s, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 0', borderBottom: i < recentAll.length - 1 ? '1px solid var(--color-border)' : 'none' }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, color: 'var(--color-text)', fontWeight: 600 }}>{s.label}</div>
                      <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>{s.summary}</div>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--color-muted)', flexShrink: 0 }}>{fmtDate(s.date)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Reset */}
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            {!confirmClear ? (
              <button onClick={() => setConfirmClear(true)} style={{ fontSize: 12, color: 'var(--color-muted)', background: 'none', border: '1px solid var(--color-border)', borderRadius: 8, padding: '6px 14px', cursor: 'pointer' }}>
                Statistieken wissen
              </button>
            ) : (
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ fontSize: 12, color: 'var(--color-muted)' }}>Zeker weten?</span>
                <button onClick={doReset} style={{ fontSize: 12, color: '#ef4444', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, padding: '6px 14px', cursor: 'pointer', fontWeight: 700 }}>Ja, wis alles</button>
                <button onClick={() => setConfirmClear(false)} style={{ fontSize: 12, color: 'var(--color-muted)', background: 'none', border: '1px solid var(--color-border)', borderRadius: 8, padding: '6px 14px', cursor: 'pointer' }}>Annuleer</button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
