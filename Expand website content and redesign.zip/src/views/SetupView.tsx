import type { GameId, Level } from '../types';

interface Props {
  game: GameId;
  onSelectLevel: (l: Level) => void;
  onBack: () => void;
}

const META = {
  rekensnelheid: { icon: '⚡', title: 'RekenSnelheid', color: '#f59e0b', colorBg: 'rgba(245,158,11,0.08)', colorBorder: 'rgba(245,158,11,0.25)' },
  peeler:        { icon: '🧅', title: 'Math Peeler',    color: '#a855f7', colorBg: 'rgba(168,85,247,0.08)', colorBorder: 'rgba(168,85,247,0.25)' },
  verhaaltjes:   { icon: '📖', title: 'Verhaaltjessommen', color: '#10b981', colorBg: 'rgba(16,185,129,0.08)', colorBorder: 'rgba(16,185,129,0.25)' },
};

const LEVEL_LABELS: Record<GameId, [string, string][]> = {
  rekensnelheid: [['Niveau 1', '5 sommen · makkelijk'], ['Niveau 2', '10 sommen · gemiddeld'], ['Niveau 3', '15 sommen · moeilijk']],
  peeler:        [['Niveau 1', '3 lagen · basisoperaties'], ['Niveau 2', '6 lagen · alle operaties'], ['Niveau 3', '10 lagen · uitdagend']],
  verhaaltjes:   [['Niveau 1', 'Basis verhaalsom'], ['Niveau 2', 'Gemiddeld niveau'], ['Niveau 3', 'Gevorderd']],
};

const LVL_COLORS = [
  { c: '#22c55e', bg: 'rgba(34,197,94,0.07)', b: 'rgba(34,197,94,0.3)' },
  { c: '#f59e0b', bg: 'rgba(245,158,11,0.07)', b: 'rgba(245,158,11,0.3)' },
  { c: '#ef4444', bg: 'rgba(239,68,68,0.07)', b: 'rgba(239,68,68,0.3)' },
];

export default function SetupView({ game, onSelectLevel, onBack }: Props) {
  const m = META[game];
  const highScore = game === 'peeler'
    ? parseInt(localStorage.getItem('peeler_infinite_highscore') || '0', 10)
    : null;

  return (
    <div style={{ maxWidth: 540, margin: '32px auto 0' }}>
      <div style={{
        backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)',
        borderRadius: 20, padding: 32, textAlign: 'center',
      }}>
        <div style={{ fontSize: 52, marginBottom: 12 }}>{m.icon}</div>
        <h2 style={{ fontFamily: 'var(--font-mono)', fontSize: 24, fontWeight: 800, color: 'var(--color-text)', marginBottom: 6 }}>
          {m.title}
        </h2>
        <p style={{ fontSize: 13, color: 'var(--color-muted)', marginBottom: 28, lineHeight: 1.6 }}>
          Kies je moeilijkheidsgraad om te beginnen. Je kunt altijd opnieuw spelen op een ander niveau.
        </p>

        {game === 'peeler' && highScore !== null && (
          <div style={{
            background: m.colorBg, border: `1px solid ${m.colorBorder}`,
            borderRadius: 12, padding: '14px 20px', marginBottom: 24,
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--color-muted)', marginBottom: 4 }}>
              High Score Infinite Mode
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 40, fontWeight: 800, color: m.color }}>
              {highScore}
            </div>
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 14 }}>
          {[1, 2, 3].map(lvl => {
            const lc = LVL_COLORS[lvl - 1];
            const [line1, line2] = LEVEL_LABELS[game][lvl - 1];
            return (
              <button
                key={lvl}
                onClick={() => onSelectLevel(lvl as Level)}
                style={{
                  padding: '16px 8px', borderRadius: 12, border: `2px solid ${lc.b}`,
                  background: lc.bg, color: lc.c, fontWeight: 700, fontSize: 13,
                  cursor: 'pointer', transition: 'transform 0.15s, filter 0.15s',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5,
                }}
                onMouseOver={e => { e.currentTarget.style.transform = 'scale(1.03)'; e.currentTarget.style.filter = 'brightness(1.1)'; }}
                onMouseOut={e => { e.currentTarget.style.transform = 'scale(1)'; e.currentTarget.style.filter = 'none'; }}
              >
                <span style={{ fontSize: 14 }}>{line1}</span>
                <span style={{ fontSize: 11, fontWeight: 500, opacity: 0.8 }}>{line2}</span>
              </button>
            );
          })}
        </div>

        {game === 'peeler' && (
          <button
            onClick={() => onSelectLevel('infinite')}
            style={{
              width: '100%', padding: '14px', borderRadius: 12, marginBottom: 20,
              border: '2px solid rgba(168,85,247,0.4)', background: 'rgba(168,85,247,0.08)',
              color: '#c084fc', fontWeight: 700, fontSize: 14, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              transition: 'filter 0.15s',
            }}
            onMouseOver={e => e.currentTarget.style.filter = 'brightness(1.1)'}
            onMouseOut={e => e.currentTarget.style.filter = 'none'}
          >
            <span>♾️</span> Infinite Mode — zolang je goed blijft antwoorden
          </button>
        )}

        <button
          onClick={onBack}
          style={{ fontSize: 13, color: 'var(--color-muted)', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 3 }}
        >
          ← Terug naar overzicht
        </button>
      </div>
    </div>
  );
}
