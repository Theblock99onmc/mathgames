import { useState } from 'react';

interface F { id: string; cat: string; name: string; formula: string; desc: string; vars?: string; example?: string; }

const FORMULAS: F[] = [
  { id: 'lin', cat: 'Algebra', name: 'Lineaire Functie', formula: 'y = ax + b', desc: 'Rechte lijn. a = richtingscoëfficiënt (stijging), b = snijpunt y-as.', example: 'y = 2x + 3 → stijgt 2 per stap, begint op y=3' },
  { id: 'kwadf', cat: 'Algebra', name: 'Kwadratische Functie', formula: 'y = ax² + bx + c', desc: 'Parabool. Toppunt op x = −b/(2a).', vars: 'a ≠ 0' },
  { id: 'abc', cat: 'Algebra', name: 'ABC-formule', formula: 'x = (−b ± √(b²−4ac)) / 2a', desc: 'Oplossingen van ax² + bx + c = 0. D = b²−4ac is de discriminant.', example: 'x²−5x+6=0 → x=3 of x=2' },
  { id: 'disc', cat: 'Algebra', name: 'Discriminant', formula: 'D = b² − 4ac', desc: 'D > 0: twee oplossingen  |  D = 0: één oplossing  |  D < 0: geen reële oplossing', vars: 'Uit ax² + bx + c = 0' },
  { id: 'mp', cat: 'Algebra', name: 'Machten — Product', formula: 'aⁿ × aᵐ = aⁿ⁺ᵐ', desc: 'Zelfde grondtal: machten optellen.', example: '2³ × 2⁴ = 2⁷ = 128' },
  { id: 'mq', cat: 'Algebra', name: 'Machten — Quotiënt', formula: 'aⁿ ÷ aᵐ = aⁿ⁻ᵐ', desc: 'Zelfde grondtal: machten aftrekken.', example: '3⁵ ÷ 3² = 3³ = 27' },
  { id: 'mm', cat: 'Algebra', name: 'Macht van een Macht', formula: '(aⁿ)ᵐ = aⁿˣᵐ', desc: 'Machten vermenigvuldigen.', example: '(2³)² = 2⁶ = 64' },
  { id: 'm0', cat: 'Algebra', name: 'Nulde Macht', formula: 'a⁰ = 1  (a ≠ 0)', desc: 'Elk getal (behalve 0) tot de macht 0 is 1.' },
  { id: 'mn', cat: 'Algebra', name: 'Negatieve Macht', formula: 'a⁻ⁿ = 1 / aⁿ', desc: 'Negatieve macht schrijf je als breuk.', example: '2⁻³ = 1/8' },
  { id: 'logp', cat: 'Algebra', name: 'Log — Product', formula: 'log(a × b) = log(a) + log(b)', desc: 'Logaritme van een product splitsen in een som.' },
  { id: 'logq', cat: 'Algebra', name: 'Log — Quotiënt', formula: 'log(a / b) = log(a) − log(b)', desc: 'Logaritme van een quotiënt splitsen in een verschil.' },
  { id: 'logm', cat: 'Algebra', name: 'Log — Macht', formula: 'log(aⁿ) = n × log(a)', desc: 'Macht voor de log zetten.' },
  { id: 'rect', cat: 'Meetkunde', name: 'Rechthoek — Oppervlakte & Omtrek', formula: 'O = l × b  |  U = 2(l + b)', desc: 'Oppervlakte en omtrek van een rechthoek.', vars: 'l = lengte, b = breedte' },
  { id: 'sqr', cat: 'Meetkunde', name: 'Vierkant — Oppervlakte & Omtrek', formula: 'O = z²  |  U = 4z', desc: 'Oppervlakte en omtrek van een vierkant.', vars: 'z = zijde' },
  { id: 'tri', cat: 'Meetkunde', name: 'Driehoek — Oppervlakte', formula: 'O = ½ × b × h', desc: 'Basis maal hoogte gedeeld door 2.', vars: 'b = basis, h = loodrechte hoogte' },
  { id: 'circ', cat: 'Meetkunde', name: 'Cirkel — Oppervlakte & Omtrek', formula: 'O = πr²  |  U = 2πr = πd', desc: 'Gebruik altijd de straal r (= helft van diameter d).', vars: 'r = straal, π ≈ 3,14159', example: 'r=5 → O≈78,5 cm²' },
  { id: 'pyth', cat: 'Meetkunde', name: 'Stelling van Pythagoras', formula: 'a² + b² = c²', desc: 'In een rechthoekige driehoek: kwadraten van rechthoekszijden = kwadraat schuine zijde.', vars: 'c = schuine zijde (hypotenusa)', example: '3² + 4² = 5²  →  9 + 16 = 25 ✓' },
  { id: 'balk', cat: 'Meetkunde', name: 'Balk — Volume', formula: 'V = l × b × h', desc: 'Lengte × breedte × hoogte.', vars: 'l,b,h in zelfde eenheid' },
  { id: 'cyl', cat: 'Meetkunde', name: 'Cilinder — Volume', formula: 'V = πr²h', desc: 'Grondvlak (cirkel) × hoogte.', vars: 'r = straal, h = hoogte' },
  { id: 'bol', cat: 'Meetkunde', name: 'Bol — Volume', formula: 'V = (4/3)πr³', desc: 'Vier derde × pi × straal tot de derde.', example: 'r=3 → V = (4/3)π×27 ≈ 113 cm³' },
  { id: 'kegel', cat: 'Meetkunde', name: 'Kegel — Volume', formula: 'V = (1/3)πr²h', desc: 'Eén derde van cilindervolume.' },
  { id: 'sin', cat: 'Meetkunde', name: 'Sinus', formula: 'sin(α) = overstaand / schuins', desc: 'In een rechthoekige driehoek: overstaande zijde gedeeld door schuine zijde.' },
  { id: 'cos', cat: 'Meetkunde', name: 'Cosinus', formula: 'cos(α) = aanliggend / schuins', desc: 'Aanliggende zijde gedeeld door schuine zijde.' },
  { id: 'tan', cat: 'Meetkunde', name: 'Tangens', formula: 'tan(α) = overstaand / aanliggend', desc: 'Overstaande gedeeld door aanliggende zijde.' },
  { id: 'gem', cat: 'Statistiek', name: 'Gemiddelde', formula: 'x̄ = Σxᵢ / n', desc: 'Som van alle waarden gedeeld door het aantal.', example: 'Gem.(3,7,5,9) = 24/4 = 6' },
  { id: 'var', cat: 'Statistiek', name: 'Variantie', formula: 'σ² = Σ(xᵢ − x̄)² / n', desc: 'Gemiddelde kwadratische afwijking van het gemiddelde.' },
  { id: 'std', cat: 'Statistiek', name: 'Standaardafwijking', formula: 'σ = √(σ²)', desc: 'Wortel uit de variantie. Maat voor spreiding.' },
  { id: 'pv', cat: 'Statistiek', name: 'Procentuele Verandering', formula: 'Δ% = ((nieuw − oud) / oud) × 100%', desc: 'Relatieve verandering in procenten.', example: '€40 → €50: (10/40)×100 = 25%' },
  { id: 'exp', cat: 'Statistiek', name: 'Exponentiële Groei', formula: 'A(t) = A₀ × (1 + r)ᵗ', desc: 'Waarde na t tijdseenheden bij vaste groeivoet r.', vars: 'A₀ = beginwaarde, r = groeivoet, t = tijd' },
];

const CATS = Array.from(new Set(FORMULAS.map(f => f.cat)));
const CC: Record<string, { color: string; bg: string; border: string }> = {
  Algebra:    { color: '#818cf8', bg: 'rgba(99,102,241,0.08)',   border: 'rgba(99,102,241,0.22)' },
  Meetkunde:  { color: '#22d3ee', bg: 'rgba(6,182,212,0.08)',    border: 'rgba(6,182,212,0.22)' },
  Statistiek: { color: '#fb7185', bg: 'rgba(244,63,94,0.08)',    border: 'rgba(244,63,94,0.22)' },
};

interface Props { onHome: () => void; }

export default function FormulesView({ onHome }: Props) {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState<string | null>(null);

  const q = search.toLowerCase();
  const list = FORMULAS.filter(f =>
    (!cat || f.cat === cat) &&
    (!q || f.name.toLowerCase().includes(q) || f.formula.toLowerCase().includes(q) || f.desc.toLowerCase().includes(q))
  );

  return (
    <div style={{ maxWidth: 880, margin: '0 auto' }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <div style={{ width: 38, height: 38, background: 'rgba(6,182,212,0.12)', border: '1px solid rgba(6,182,212,0.25)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>📐</div>
          <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 800, color: 'var(--color-text)' }}>Formuleboek</h1>
        </div>
        <p style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.7 }}>
          Alle basisformules op één plek. Zoek op naam of formule, of filter op onderwerp.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Zoek een formule..."
          style={{ flex: 1, minWidth: 200, background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 10, padding: '8px 14px', fontSize: 13, color: 'var(--color-text)', outline: 'none', transition: 'border-color 0.15s' }}
          onFocus={e => e.target.style.borderColor = '#6366f1'}
          onBlur={e => e.target.style.borderColor = 'var(--color-border)'}
        />
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <button onClick={() => setCat(null)} style={{ padding: '7px 14px', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', background: !cat ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.04)', color: !cat ? 'var(--color-text)' : 'var(--color-muted)', border: '1px solid var(--color-border)', transition: 'all 0.15s' }}>
            Alle ({FORMULAS.length})
          </button>
          {CATS.map(c => {
            const cc = CC[c];
            const active = cat === c;
            return (
              <button key={c} onClick={() => setCat(active ? null : c)} style={{ padding: '7px 14px', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', background: active ? cc.bg : 'rgba(255,255,255,0.04)', color: active ? cc.color : 'var(--color-muted)', border: `1px solid ${active ? cc.border : 'var(--color-border)'}`, transition: 'all 0.15s' }}>
                {c}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ fontSize: 12, color: 'var(--color-muted)', marginBottom: 14 }}>
        {list.length} formule{list.length !== 1 ? 's' : ''} gevonden
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 10 }}>
        {list.map(f => {
          const cc = CC[f.cat] || { color: '#ccc', bg: 'rgba(255,255,255,0.04)', border: 'var(--color-border)' };
          return (
            <div key={f.id} style={{ backgroundColor: 'var(--color-surface)', border: `1px solid ${cc.border}`, borderRadius: 14, padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10, gap: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--color-text)', lineHeight: 1.4 }}>{f.name}</span>
                <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.05em', textTransform: 'uppercase', color: cc.color, background: cc.bg, border: `1px solid ${cc.border}`, padding: '2px 7px', borderRadius: 5, whiteSpace: 'nowrap', flexShrink: 0 }}>
                  {f.cat}
                </span>
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: cc.color, background: cc.bg, border: `1px solid ${cc.border}`, borderRadius: 8, padding: '7px 12px', marginBottom: 8 }}>
                {f.formula}
              </div>
              <p style={{ fontSize: 12, color: 'var(--color-muted)', lineHeight: 1.55, marginBottom: f.vars || f.example ? 7 : 0 }}>{f.desc}</p>
              {f.vars && <div style={{ fontSize: 11, color: 'var(--color-muted)', fontStyle: 'italic', lineHeight: 1.5, marginBottom: f.example ? 6 : 0 }}>{f.vars}</div>}
              {f.example && <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: cc.color, background: `${cc.bg}`, borderRadius: 6, padding: '5px 10px', marginTop: f.vars ? 6 : 0 }}>▶ {f.example}</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
