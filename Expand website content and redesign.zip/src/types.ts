export type GameId = 'rekensnelheid' | 'peeler' | 'verhaaltjes';
export type ViewId = 'hub' | 'setup' | 'game1' | 'game2' | 'game3' | 'theorie' | 'formules' | 'voortgang';
export type Level = 1 | 2 | 3 | 'infinite';
export type FontMode = 'outfit' | 'lexend' | 'dyslexic';
export type ThemeMode = 'dark' | 'light' | 'oled';
