import { useState, useEffect, useRef, useCallback } from 'react';
import type { Level } from '../types';
import { saveG2Stat } from '../utils/stats';

declare global { interface Window { MathJax: any; } }

interface StackItem { key: string; v: string; }

const VARS = ['a','b','c','x','y','z'];
const ALL_OPS = [
  { key: 's', label: 'Som (+)' }, { key: 'm', label: 'Min (−)' },
  { key: 'k', label: 'Keer (×)' }, { key: 'd', label: 'Delen (÷)' },
  { key: 'p', label: 'Macht (^)' }, { key: 'r', label: 'Wortel (√)' },
];
const BASIC_OPS = ALL_OPS.slice(0, 4);

function buildTex(stack: StackItem[], isInf: boolean): string {
  let s = isInf ? 'Q' : 'x';
  for (const { key, v } of stack) {
    if (key === 's') s = `\\left(${s} + ${v}\\right)`;
    else if (key === 'm') s = `\\left(${s} - ${v}\\right)`;
    else if (key === 'k') s = `\\left(${s} \\cdot ${v}\\right)`;
    else if (key === 'd') s = `\\dfrac{${s}}{${v}}`;
    else if (key === 'p') s = `{\\left(${s}\\right)}^{${v}}`;
    else if (key === 'r') s = `\\sqrt[${v}]{${s}}`;
  }
  return `\\[${s}\\]`;
}

function rndItem<T>(arr: T[]) { return arr[Math.floor(Math.random() * arr.length)]; }
function rndStack(size: number, opsPool: typeof ALL_OPS): StackItem[] {
  return Array.from({ length: size }, () => ({ key: rndItem(opsPool).key, v: rndItem(VARS) }));
}

interface Props { level: Level; onHome: () => void; onReplay: () => void; }

export default function Game2View({ level, onHome, onReplay }: Props) {
  const isInf = level === 'infinite';
  const initialSize = isInf ? 5 : level === 1 ? 3 : level === 2 ? 6 : 10;
  const opsPool = (level === 1) ? BASIC_OPS : ALL_OPS;

  const [stack, setStack] = useState<StackItem[]>(() => rndStack(initialSize, isInf ? ALL_OPS : opsPool));
  const [score, setScore] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [fbColor, setFbColor] = useState('#22c55e');
  const [flash, setFlash] = useState('');
  const [playing, setPlaying] = useState(true);
  const [done, setDone] = useState(false);
  const [doneTime, setDoneTime] = useState(0);
  const [newHs, setNewHs] = useState(false);

  const startTime = useRef(Date.now());
  const timerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const eqRef = useRef<HTMLDivElement>(null);
  const stackRef = useRef(stack); stackRef.current = stack;
  const scoreRef = useRef(score); scoreRef.current = score;
  const playingRef = useRef(playing); playingRef.current = playing;

  useEffect(() => {
    timerRef.current = setInterval(() => setElapsed((Date.now()-startTime.current)/1000), 100);
    return () => clearInterval(timerRef.current);
  }, []);

  useEffect(() => {
    if (!eqRef.current) return;
    eqRef.current.innerHTML = buildTex(stack, isInf);
    if (window.MathJax?.typesetPromise) {
      window.MathJax.typesetPromise([eqRef.current]).catch(() => {});
    }
  }, [stack, isInf]);

  const scaleFactor = Math.max(1.4, Math.min(3.6, 1.8 + (12 - stack.length) * 0.22));

  const endNormal = useCallback(() => {
    const tt = (Date.now() - startTime.current) / 1000;
    clearInterval(timerRef.current);
    playingRef.current = false; setPlaying(false);
    setDoneTime(tt); setDone(true);
    saveG2Stat({ date: Date.now(), level: level as number, time: tt, score: 0, infinite: false, newHs: false });
  }, [level]);

  const endInfinite = useCallback((finalScore: number) => {
    clearInterval(timerRef.current);
    playingRef.current = false; setPlaying(false);
    const oldHs = parseInt(localStorage.getItem('peeler_infinite_highscore') || '0', 10);
    const isNew = finalScore > oldHs;
    if (isNew) localStorage.setItem('peeler_infinite_highscore', String(finalScore));
    setNewHs(isNew); setDone(true);
    saveG2Stat({ date: Date.now(), level: 'infinite', time: (Date.now()-startTime.current)/1000, score: finalScore, infinite: true, newHs: isNew });
  }, []);

  const handleInput = useCallback((k: string) => {
    if (!playingRef.current) return;
    const kl = k.toLowerCase();
    if (!['s','m','k','d','p','r'].includes(kl)) return;
    const st = stackRef.current; if (st.length === 0) return;
    const outer = st[st.length - 1];

    if (kl === outer.key) {
      const newSt = st.slice(0, -1);
      if (isInf) {
        const ns = scoreRef.current + 1;
        setScore(ns);
        const newItem = { key: rndItem(ALL_OPS).key, v: rndItem(VARS) };
        setStack([newItem, ...newSt]);
        setFeedback('+1!'); setFbColor('#22c55e');
        setFlash('correct-flash'); setTimeout(() => setFlash(''), 400);
      } else {
        setStack(newSt);
        if (newSt.length === 0) { endNormal(); return; }
        setFeedback(`Correct! ${newSt.length} lagen te gaan.`); setFbColor('#22c55e');
        setFlash('correct-flash'); setTimeout(() => setFlash(''), 400);
      }
    } else {
      if (isInf) {
        setFlash('wrong-flash'); setTimeout(() => setFlash(''), 400);
        setFeedback('Fout! Game Over.'); setFbColor('#ef4444');
        endInfinite(scoreRef.current);
      } else {
        setFeedback('Fout! Probeer opnieuw.'); setFbColor('#ef4444');
        setFlash('wrong-flash'); setTimeout(() => setFlash(''), 400);
      }
    }
  }, [isInf, endNormal, endInfinite]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => handleInput(e.key);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [handleInput]);

  const card = { backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 16 };

  if (done) return (
    <div style={{ maxWidth: 440, margin: '32px auto 0' }}>
      <div style={{ ...card, borderRadius: 20, padding: 32, textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 26, fontWeight: 800, color: '#a855f7', marginBottom: 12 }}>
          {isInf ? (newHs ? '🏆 Nieuwe High Score!' : 'Game Over!') : '✨ Opgelost!'}
        </div>
        {isInf ? (
          <div style={{ marginBottom: 24 }}>
            <div style={{ fontSize: 12, color: 'var(--color-muted)', marginBottom: 6 }}>Behaalde Score</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 60, fontWeight: 800, color: '#a855f7' }}>{score}</div>
          </div>
        ) : (
          <div style={{ fontSize: 15, color: 'var(--color-muted)', marginBottom: 24 }}>
            Oplosttijd: <span style={{ color: 'var(--color-text)', fontWeight: 700, fontFamily: 'var(--font-mono)' }}>{doneTime.toFixed(2)}s</span>
          </div>
        )}
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onReplay} style={{ flex: 1, padding: 12, borderRadius: 10, background: '#a855f7', color: 'white', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>Opnieuw</button>
          <button onClick={onHome} style={{ padding: '12px 20px', borderRadius: 10, background: 'rgba(255,255,255,0.05)', color: 'var(--color-muted)', fontWeight: 600, fontSize: 13, border: '1px solid var(--color-border)', cursor: 'pointer' }}>Home</button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ maxWidth: 720, margin: '16px auto 0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', ...card, padding: '12px 16px', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 13, color: 'var(--color-muted)' }}>{isInf ? 'Score:' : 'Lagen te gaan:'}</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 800, color: '#a855f7' }}>{isInf ? score : stack.length}</span>
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color: '#a855f7' }}>{elapsed.toFixed(1)}s</span>
      </div>

      <div className={flash} style={{ ...card, borderRadius: 20, padding: '32px 24px', minHeight: 220, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative', marginBottom: 14, overflow: 'hidden', border: '2px solid var(--color-border)' }}>
        {feedback && <div style={{ position: 'absolute', top: 14, fontSize: 13, fontWeight: 700, color: fbColor }}>{feedback}</div>}
        <div ref={eqRef} style={{ fontSize: `${scaleFactor}rem`, textAlign: 'center', color: 'var(--color-text)', width: '100%' }}>
          Laden...
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
        {ALL_OPS.map(op => (
          <button
            key={op.key}
            onClick={() => handleInput(op.key)}
            style={{
              ...card, padding: '12px 4px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5,
              cursor: 'pointer', transition: 'border-color 0.15s',
            }}
            onMouseOver={e => (e.currentTarget.style.borderColor = '#a855f7')}
            onMouseOut={e => (e.currentTarget.style.borderColor = 'var(--color-border)')}
          >
            <span style={{ fontSize: 11, color: 'var(--color-muted)' }}>{op.label}</span>
            <kbd style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid var(--color-border)', padding: '3px 10px', borderRadius: 6, fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: 'var(--color-text)' }}>
              {op.key.toUpperCase()}
            </kbd>
          </button>
        ))}
      </div>
    </div>
  );
}
