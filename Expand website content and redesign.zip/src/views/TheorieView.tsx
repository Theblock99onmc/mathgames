import { useState } from 'react';

interface Topic {
  id: string; cat: string; title: string;
  explanation: string; formula?: string;
  example: { problem: string; steps: string[]; answer: string };
  tip: string;
}

const TOPICS: Topic[] = [
  {
    id: 'optellen', cat: 'Rekenen', title: 'Optellen & Aftrekken',
    explanation: 'Bij optellen voeg je hoeveelheden samen; bij aftrekken verwijder je een deel.\n\nBelangrijke regels:\n• Positief + positief = groter getal: 3 + 4 = 7\n• Negatief + negatief = negatiever: −3 + (−4) = −7\n• Tegengestelden heffen elkaar op: 5 + (−5) = 0\n• Aftrekken van een negatief getal is hetzelfde als optellen: 8 − (−2) = 10',
    formula: 'a + b = b + a  (commutatief)\n(a + b) + c = a + (b + c)  (associatief)',
    example: { problem: '347 + 256 = ?', steps: ['7 + 6 = 13 → schrijf 3, onthoud 1', '4 + 5 + 1 = 10 → schrijf 0, onthoud 1', '3 + 2 + 1 = 6'], answer: '603' },
    tip: 'Oefen de tafels tot 20 uit je hoofd. Met een vlotte mentale optelling maak je snelheidstoetsen veel makkelijker.'
  },
  {
    id: 'vermenigvuldigen', cat: 'Rekenen', title: 'Vermenigvuldigen & Delen',
    explanation: 'Vermenigvuldigen is herhaald optellen: 4 × 3 = 3 + 3 + 3 + 3 = 12.\nDelen is het eerlijk verdelen in gelijke groepen.\n\nTrucs:\n• Afsplitsen: 24 × 15 = 24 × 10 + 24 × 5\n• Delen door een breuk = vermenigvuldigen met het omgekeerde\n• Negatief × negatief = positief\n• Positief × negatief = negatief',
    formula: 'a × (b + c) = a × b + a × c  (distributief)\na ÷ (b/c) = a × (c/b)',
    example: { problem: '24 × 15 = ?', steps: ['24 × 15 = 24 × (10 + 5)', '24 × 10 = 240', '24 × 5 = 120', '240 + 120 = 360'], answer: '360' },
    tip: 'Splits moeilijke sommen: 24 × 15 = 24 × 10 + 24 × 5 = 240 + 120 = 360. Eenvoudiger dan het lijkt!'
  },
  {
    id: 'machten', cat: 'Rekenen', title: 'Machten & Wortels',
    explanation: 'Een macht is herhaalde vermenigvuldiging: 3⁴ = 3 × 3 × 3 × 3 = 81.\nEen wortel is het omgekeerde van een kwadraat: √9 = 3 want 3² = 9.\n\nRekenregels:\n• aⁿ × aᵐ = aⁿ⁺ᵐ  (zelfde grondtal: machten optellen)\n• (aⁿ)ᵐ = aⁿˣᵐ  (macht van een macht)\n• a⁰ = 1  (altijd, als a ≠ 0)\n• a⁻ⁿ = 1/aⁿ  (negatieve macht = breuk)',
    formula: 'aⁿ × aᵐ = aⁿ⁺ᵐ\n(aⁿ)ᵐ = aⁿˣᵐ\na⁰ = 1  (a ≠ 0)\na⁻ⁿ = 1/aⁿ',
    example: { problem: '2⁵ × 2³ = ?', steps: ['Zelfde grondtal → machten optellen', '2⁵ × 2³ = 2⁵⁺³ = 2⁸', '2⁸ = 256'], answer: '256' },
    tip: 'Leer de kwadraten tot 15 uit je hoofd: 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225. Onmisbaar!'
  },
  {
    id: 'procenten', cat: 'Procenten & Verhoudingen', title: 'Percentages Berekenen',
    explanation: 'Procent betekent "per honderd": 25% = 25/100 = 0,25.\n\nVeelgebruikte berekeningen:\n• x% van A: vermenigvuldig A met (x ÷ 100)\n• Procentuele stijging: nieuw = oud × (1 + x/100)\n• Procentuele daling: nieuw = oud × (1 − x/100)\n• Terugrekenen naar origineel: origineel = nieuw ÷ (1 + x/100)\n\nSnelle trucjes:\n• 10% = deel door 10\n• 5% = helft van 10%\n• 25% = deel door 4\n• 50% = deel door 2',
    formula: 'x% van A = (x ÷ 100) × A\nGroeifactor = 1 + (x/100)\nAfnamefactor = 1 − (x/100)',
    example: { problem: 'Een trui kost €120. Je krijgt 15% korting. Wat betaal je?', steps: ['15% van €120 = (15 ÷ 100) × 120 = €18', 'Betalen: €120 − €18 = €102', 'Of direct: 120 × 0,85 = €102'], answer: '€102' },
    tip: '15% korting betekent dat je 85% betaalt. Reken direct: 120 × 0,85 = 102. Eén stap in plaats van twee!'
  },
  {
    id: 'verhoudingen', cat: 'Procenten & Verhoudingen', title: 'Verhoudingen & Schaal',
    explanation: 'Een verhouding geeft aan hoe twee grootheden zich tot elkaar verhouden.\nVerhouding 3:4 = voor elke 3 van de eerste zijn er 4 van de tweede.\n\nSchaal:\n• 1:50.000 → 1 cm op kaart = 50.000 cm in werkelijkheid (= 500 m)\n• Altijd in dezelfde eenheid werken!\n\nVerhoudingstabellen:\nLinks en rechts kruislings vermenigvuldigen geeft gelijke producten (cross-multiply).',
    formula: 'a/b = c/d  →  a × d = b × c\nSchaal: kaart × schaalfactor = werkelijkheid',
    example: { problem: 'Op een recept voor 6 personen gebruik je 300g meel. Hoeveel voor 10 personen?', steps: ['Per persoon: 300 ÷ 6 = 50g', 'Voor 10 personen: 50 × 10 = 500g'], answer: '500g meel' },
    tip: '"Per eenheid" als tussenstap: bereken eerst de waarde voor 1, dan pas voor het gevraagde aantal. Altijd overzichtelijk.'
  },
  {
    id: 'vergelijkingen', cat: 'Algebra', title: 'Vergelijkingen Oplossen',
    explanation: 'Een vergelijking heeft een gelijkteken. Doel: de onbekende (x) isoleren.\n\nGouden regels:\n• Wat je links doet, doe je ook rechts (evenwichtsregel)\n• Termen naar de andere kant: + wordt −, × wordt ÷\n• Vermenigvuldigen/delen met negatief getal: ongelijkheidsteken draait om\n\nStappen bij een lineaire vergelijking:\n1. Haal termen met x naar links\n2. Haal getallen naar rechts\n3. Deel beide zijden door de coëfficiënt van x',
    formula: 'ax + b = c  →  x = (c − b) / a',
    example: { problem: '3x + 7 = 22', steps: ['3x = 22 − 7 = 15', 'x = 15 ÷ 3 = 5'], answer: 'x = 5' },
    tip: 'Controleer altijd: vervang x door je antwoord in de oorspronkelijke vergelijking. 3(5) + 7 = 22 ✓'
  },
  {
    id: 'abc-formule', cat: 'Algebra', title: 'Kwadratische Vergelijkingen & ABC-formule',
    explanation: 'Een kwadratische vergelijking heeft de vorm ax² + bx + c = 0.\n\nOplossingsmethoden:\n1. Ontbinden in factoren (als mogelijk)\n2. ABC-formule (werkt altijd)\n\nDiscriminant D = b² − 4ac:\n• D > 0: twee verschillende reële oplossingen\n• D = 0: één oplossing (dubbele wortel)\n• D < 0: geen reële oplossingen',
    formula: 'x = (−b ± √(b²−4ac)) / 2a\nD = b² − 4ac',
    example: { problem: 'x² − 5x + 6 = 0', steps: ['a=1, b=−5, c=6', 'D = (−5)² − 4(1)(6) = 25 − 24 = 1', 'x = (5 ± √1) / 2 = (5 ± 1) / 2', 'x = 3 of x = 2'], answer: 'x = 3 of x = 2' },
    tip: 'Controleer eerst of ontbinden mogelijk is: zoek twee getallen waarvan het product c is en de som −b. Hier: 3 × 2 = 6 en 3 + 2 = 5 ✓'
  },
  {
    id: 'oppervlakte', cat: 'Meetkunde', title: 'Oppervlakte & Omtrek',
    explanation: 'Oppervlakte is de hoeveelheid vlak (in cm², m², km²).\nOmtrek is de totale buitenrandlengte.\n\nFormules:\n• Rechthoek: O = l × b  |  U = 2(l + b)\n• Driehoek: O = ½ × b × h  |  U = a + b + c\n• Cirkel: O = π × r²  |  U = 2πr\n• Vierkant: O = z²  |  U = 4z\n• Trapezium: O = ½(a + b) × h\n• Ruit: O = ½ × d₁ × d₂',
    formula: 'Cirkel: O = πr²,  U = 2πr\nRechthoek: O = l × b,  U = 2(l+b)\nDriehoek: O = ½bh',
    example: { problem: 'Bereken de oppervlakte van een cirkel met straal 5 cm.', steps: ['Formule: O = π × r²', 'O = π × 5² = π × 25', 'O ≈ 3,14159 × 25 ≈ 78,5 cm²'], answer: '≈ 78,5 cm²' },
    tip: 'Gebruik bij cirkels altijd de straal r (= helft van diameter d). Verwar straal en diameter niet!'
  },
  {
    id: 'volume', cat: 'Meetkunde', title: 'Volume & Inhoud',
    explanation: 'Volume is de hoeveelheid ruimte die een 3D-object inneemt (in cm³, m³, dm³).\n\nOmzettingen:\n• 1 liter = 1 dm³ = 1000 cm³\n• 1 m³ = 1000 liter\n\nFormules:\n• Balk (rechthoekige doos): V = l × b × h\n• Cilinder: V = π × r² × h\n• Kegel: V = ⅓ × π × r² × h\n• Bol: V = ⁴⁄₃ × π × r³\n• Piramide: V = ⅓ × grondvlak × h',
    formula: 'Balk: V = l × b × h\nCilinder: V = πr²h\nBol: V = (4/3)πr³',
    example: { problem: 'Een zwembad is 25m lang, 10m breed, 1,5m diep. Hoeveel m³ water past er in?', steps: ['Formule balk: V = l × b × h', 'V = 25 × 10 × 1,5 = 375 m³'], answer: '375 m³' },
    tip: 'Let op eenheden! Alle maten moeten in dezelfde eenheid zijn. Zet cm om naar dm als je liters wilt berekenen.'
  },
];

const CATS = Array.from(new Set(TOPICS.map(t => t.cat)));

interface Props { onHome: () => void; }

export default function TheorieView({ onHome }: Props) {
  const [activeCat, setActiveCat] = useState(CATS[0]);
  const [open, setOpen] = useState<string | null>(null);

  const filtered = TOPICS.filter(t => t.cat === activeCat);

  return (
    <div style={{ maxWidth: 760, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <div style={{ width: 38, height: 38, background: 'rgba(99,102,241,0.12)', border: '1px solid rgba(99,102,241,0.25)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>📚</div>
          <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 800, color: 'var(--color-text)' }}>Theorie & Uitleg</h1>
        </div>
        <p style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.7, maxWidth: 600 }}>
          Beknopte uitleg per wiskundeonderwerp met formules, voorbeeldopgaven en tips. Gebruik dit als naslagwerk naast het oefenen.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        {CATS.map(cat => (
          <button
            key={cat}
            onClick={() => { setActiveCat(cat); setOpen(null); }}
            style={{
              padding: '7px 16px', borderRadius: 9, fontSize: 13, fontWeight: 600, cursor: 'pointer',
              backgroundColor: activeCat === cat ? 'rgba(99,102,241,0.14)' : 'rgba(255,255,255,0.04)',
              color: activeCat === cat ? '#818cf8' : 'var(--color-muted)',
              border: activeCat === cat ? '1px solid rgba(99,102,241,0.3)' : '1px solid var(--color-border)',
              transition: 'all 0.15s',
            }}
          >{cat}</button>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {filtered.map(t => {
          const isOpen = open === t.id;
          return (
            <div key={t.id} style={{
              backgroundColor: 'var(--color-surface)',
              border: `1px solid ${isOpen ? 'rgba(99,102,241,0.3)' : 'var(--color-border)'}`,
              borderRadius: 14, overflow: 'hidden', transition: 'border-color 0.2s',
            }}>
              <button
                onClick={() => setOpen(isOpen ? null : t.id)}
                style={{ width: '100%', padding: '16px 20px', textAlign: 'left', background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}
              >
                <span style={{ fontWeight: 700, fontSize: 15, color: 'var(--color-text)' }}>{t.title}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--color-muted)', transform: isOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s', flexShrink: 0 }}>↓</span>
              </button>

              {isOpen && (
                <div style={{ padding: '0 20px 22px' }}>
                  <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: 16, marginBottom: 16 }}>
                    <p style={{ fontSize: 14, color: 'var(--color-muted)', lineHeight: 1.8, whiteSpace: 'pre-line', margin: 0 }}>{t.explanation}</p>
                  </div>

                  {t.formula && (
                    <div style={{ background: 'rgba(99,102,241,0.07)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 10, padding: '12px 14px', marginBottom: 16 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: '#818cf8', marginBottom: 8 }}>Formules</div>
                      <pre style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: '#c7d2fe', margin: 0, whiteSpace: 'pre-wrap', lineHeight: 1.8 }}>{t.formula}</pre>
                    </div>
                  )}

                  <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid var(--color-border)', borderRadius: 12, padding: 16, marginBottom: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: 'var(--color-muted)', marginBottom: 12 }}>Voorbeeldopgave</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: 'var(--color-text)', marginBottom: 12 }}>{t.example.problem}</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 7, marginBottom: 12 }}>
                      {t.example.steps.map((step, i) => (
                        <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, fontWeight: 700, color: '#6366f1', background: 'rgba(99,102,241,0.14)', padding: '2px 7px', borderRadius: 4, marginTop: 2, flexShrink: 0 }}>
                            {i + 1}
                          </span>
                          <span style={{ fontSize: 13, color: 'var(--color-muted)', lineHeight: 1.65 }}>{step}</span>
                        </div>
                      ))}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.22)', borderRadius: 8, padding: '8px 12px' }}>
                      <span style={{ fontSize: 12, color: '#22c55e', fontWeight: 700 }}>Antwoord:</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 800, color: '#4ade80' }}>{t.example.answer}</span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 10, padding: 12 }}>
                    <span style={{ fontSize: 15, flexShrink: 0 }}>💡</span>
                    <p style={{ fontSize: 13, color: '#fbbf24', lineHeight: 1.65, margin: 0 }}>{t.tip}</p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
